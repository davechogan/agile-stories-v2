"""
Agile Coach Analysis Worker Lambda

This Lambda processes stories from SQS, sending them to the OpenAI API
for Agile Coach analysis and storing the results in DynamoDB.

Flow:
1. Receives message from SQS with story_id
2. Retrieves original story from DynamoDB
3. Sends to OpenAI for Agile Coach analysis
4. Stores analysis results in DynamoDB

Environment Variables:
    DYNAMODB_TABLE: DynamoDB table name
    OPENAI_API_KEY: OpenAI API key
"""

import json
import os
import boto3
import requests
from datetime import datetime

# Initialize AWS services
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

def handler(event, context):
    try:
        print("Received event:", json.dumps(event))
        
        # Get the message from SQS
        message = json.loads(event['Records'][0]['body'])
        story_id = message['story_id']
        print(f"Processing story: {story_id}")

        # Get the original story from DynamoDB
        response = table.get_item(
            Key={
                'story_id': story_id,
                'version': 'ORIGINAL'
            }
        )
        original_story = response['Item']
        print(f"Retrieved story: {json.dumps(original_story)}")

        # Analyze with OpenAI
        analysis = analyze_story(original_story)
        print(f"Analysis complete: {json.dumps(analysis)}")

        # Save analysis back to DynamoDB
        table.put_item(
            Item={
                'story_id': story_id,
                'version': 'ANALYSIS',
                'title': original_story['title'],
                'description': original_story['description'],
                'story': original_story['story'],
                'acceptance_criteria': original_story['acceptance_criteria'],
                'analysis': analysis,
                'status': 'COMPLETED',
                'timestamp': datetime.utcnow().isoformat()
            }
        )
        print(f"Saved analysis for story: {story_id}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Analysis completed successfully'})
        }
        
    except Exception as e:
        print(f"Error processing message: {str(e)}")
        print(f"Event: {json.dumps(event)}")
        raise

def analyze_story(story):
    """
    Analyzes a user story and generates an analysis report
    
    Args:
        story (dict): The user story to analyze
        
    Returns:
        str: Analysis report of the story
    """
    # Access nested content fields
    title = story['content']['title']
    description = story['content']['description']
    acceptance_criteria = story['content']['acceptance_criteria']
    
    # Generate analysis
    analysis = f"""
Title: {title}
Description: {description}
Acceptance Criteria:
{chr(10).join(f"- {ac}" for ac in acceptance_criteria)}
"""
    return analysis 